module LearningJava {
}